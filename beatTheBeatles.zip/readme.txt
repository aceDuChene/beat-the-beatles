# Starting the Program
You will need to download the .zip file and unzip it.
You can double-click to run the game or use the terminal.
Enter into the newly created folder through your terminal.
Now, you can type "./beatTheBeatles.exe" to start the game
and follow the prompts.

# Disclaimer
This is a fan game and is in no way associated with the actual The Beatles.
Please don't tell them.